pub mod entropy;
